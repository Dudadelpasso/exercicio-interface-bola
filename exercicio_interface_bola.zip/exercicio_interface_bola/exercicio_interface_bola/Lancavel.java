public interface Lancavel {
    public default void lancar(){

    }
}