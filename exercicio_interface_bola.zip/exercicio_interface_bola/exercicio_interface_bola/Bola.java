public abstract class Bola {
    private String nomeDaBola;

    public Bola(String nomeDaBola){
        this.nomeDaBola = nomeDaBola;
    }

    public String getNomeDaBola() {
        return nomeDaBola;
    }

    public void setNomeDaBola(String nomeDaBola) {
        this.nomeDaBola = nomeDaBola;
    }

    public abstract void quicar();
}