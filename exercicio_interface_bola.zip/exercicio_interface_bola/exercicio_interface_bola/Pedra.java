public class Pedra implements Lancavel {
    public void lancar(){
        System.out.println("Você lançou a pedra!!");
    }
}
