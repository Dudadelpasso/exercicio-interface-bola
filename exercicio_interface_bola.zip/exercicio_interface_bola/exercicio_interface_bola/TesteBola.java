public class TesteBola{
    public static void main (String args[]) {
        Pedra pedregulho = new Pedra();
        pedregulho.lancar();

        BolaDeBoliche rhino = new BolaDeBoliche("Adidas");
        rhino.lancar();
        rhino.quicar();

        BolaDeFutebol pelota = new BolaDeFutebol("umbro");
        pelota.lancar();
        pelota.quicar();
    }
}