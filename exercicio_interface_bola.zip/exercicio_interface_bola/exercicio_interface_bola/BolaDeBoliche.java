public class BolaDeBoliche extends Bola{
    

    public BolaDeBoliche(String nomeDaBola) {
        super(nomeDaBola);
        //TODO Auto-generated constructor stub
    }

    public void lancar() {
        System.out.println("Bolas de boliche da marca " +getNomeDaBola()+ " são boas para lancar.");
    }

    public void quicar() {
        System.out.println("Bolas de boliche não quicam muito.");
    }

}
