public class BolaDeFutebol extends Bola {
    public BolaDeFutebol(String nomeDaBola) {
        super(nomeDaBola);
        //TODO Auto-generated constructor stub
    }

    public void lancar() {
        System.out.println("Bolas de futebol da marca " +getNomeDaBola()+ " são boas para lancar.");
    }

    public void quicar() {
        System.out.println("Bolas de futebol quicam bastante.");
    }
}